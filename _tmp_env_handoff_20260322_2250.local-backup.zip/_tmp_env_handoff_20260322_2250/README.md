﻿# mail_based_task_manager 环境交接包

生成时间：2026-03-22  
仓库路径：`E:\projects\mail_based_task_manager`

## 1. 本机最小开发环境结论

- 本机实际 Python：`.\.venv\Scripts\python.exe` -> `Python 3.11.7`
- 根目录不存在 `config.yaml`
- 根目录存在：
  - `mail_config.local.yaml`
  - `mail_config.bot.local.yaml`
  - `mail_config.cos.local.yaml`
- 当前 live host 常用配置文件：`_tmp_live_mail_runner/mail_config.loop_30s.yaml`
- 依赖文件：`repo/requirements.txt`

注意：

- 这个包没有携带整个 `.venv`，新机器需要自己重建虚拟环境并安装 `requirements.txt`
- 当前仓库和本机环境实际跑在 Python 3.11.7，不是 3.12.x

## 2. 邮件链路识别结果

- bot mailbox：
  - 配置文件：`repo/mail_config.bot.local.yaml`
  - 邮箱：`sgjcc@qq.com`
- sender / user mailbox：
  - 配置文件：`repo/mail_config.local.yaml`
  - 邮箱：`jiangchun@tongji.edu.cn`
- 当前 live smoke 默认更接近 bot mailbox 配置：
  - 文件：`live/mail_config.loop_30s.yaml`
  - 邮箱：`sgjcc@qq.com`

## 3. Codex / OpenCode 命令落点

- `codex`
  - 命令路径：`C:\Users\Administrator\bin\codex.ps1`
  - 版本：`codex-cli 0.116.0`
- `opencode`
  - 命令路径：`C:\Users\Administrator\AppData\Roaming\npm\opencode.ps1`
  - 版本：`1.2.25`
- Codex 本机配置已附带：
  - `external/codex_config.toml`
- 没有把 `C:\Users\Administrator\.codex\auth.json` 打进包里
  - 新机器大概率仍需要重新登录 Codex

配置判断：

- 当前本地配置里 `codex_command` / `opencode_command` 都是空字符串，依赖自动发现
- 当前本地配置里没有覆写 `codex_transport_default`
- 因此 repo 默认仍应按 `config.example.yaml` 读取为 `sdk`
- 当前本地配置里没有覆写：
  - `codex_sdk_sidecar_command`
  - `codex_sdk_sidecar_workdir`
  - `codex_profile_models`
  - `opencode_profile_models`

## 4. VPS / Relay 结果

### 4.1 已找到的本地材料

- SSH key：`external/work_bot.pem`
- VPS 速记：`external/vps.txt`
  - 这个文件原始编码显示有乱码
  - 结合本机读取结果，可解释为：
    - IP：`124.223.41.153`
    - 账号：`root`
    - 密码：`Sgjcc@12345`
- 部署脚本：
  - `repo/scripts/deploy_relay_server.py`
  - `repo/scripts/sync_relay_task_root.py`
- 部署/运维文档：
  - `repo/docs/plans/vps_relay_deploy_runbook.md`

### 4.2 已找到的 relay 客户端片段

- 历史 live artifact：
  - `live/relay_artifacts/relay_client_config.yaml`
  - `live/relay_artifacts/relay-ca.crt`
  - `live/relay_artifacts/relay_live_deploy.md`

其中记录了：

- `relay_url: wss://124.223.41.153:8787/relay`
- `relay_transport_token: n_Wzz--Q_j4e_sI7uZHxGlttRLZHNns1z4y3MWVHVTU`
- `relay_verify_tls: true`
- `relay_ca_file: .../relay-ca.crt`

### 4.3 当前 live 状态复核

我在打包时重新做了公网健康检查：

- `curl http://124.223.41.153:8787/healthz`
- 返回：
  - `status=ok`
  - `state_dir=/opt/mail_runner_relay/shared/state`
  - `tls_enabled=false`
  - `taskmail_direct_ingress_enabled=true`
  - `auth.transport_token_id=6f05b17d957d`

同时我校验了历史 artifact 里的 token 指纹：

- `token_fingerprint(n_Wzz--Q_j4e_sI7uZHxGlttRLZHNns1z4y3MWVHVTU) = 6f05b17d957d`

结论：

- 历史 artifact 中的 `relay_transport_token` 目前仍匹配线上服务指纹
- 但 transport scheme 已经漂移
  - 历史 artifact 写的是 `wss/https + 自签 CA`
  - 当前公网健康检查显示的是 `tls_enabled=false`
- 所以：
  - 这个包里的 `relay_client_config.yaml` 可以作为 token 来源和历史部署留档
  - 但不应直接当成“当前默认连接方式”
  - 迁移到新机器后，应优先按当前 live 状态先走 `http/ws` 侧验证，再决定是否恢复 TLS 配置

## 5. TaskMail direct bridge 相关判断

当前只能稳定确认：

- `taskmail_direct_ingress_enabled=true`
- bot mailbox 很可能是 `sgjcc@qq.com`
- user mailbox 很可能是 `jiangchun@tongji.edu.cn`

但以下项没有在本地找到一份明确、最新、可直接复用的独立配置文件：

- `taskmail-bot-mailbox-addr`
- `taskmail-direct-from-addr`
- `taskmail-direct-smtp-host`
- `taskmail-direct-smtp-port`
- `taskmail-direct-smtp-user`
- `taskmail-direct-smtp-password`

因此这部分目前只能做“高可信推断”，不能当作本地明文落盘事实。

## 6. COS 结果

- 已找到：
  - `repo/mail_config.cos.local.yaml`
- 里面已有：
  - `cos_region`
  - `cos_bucket`
  - `cos_secret_id`
  - `cos_secret_key`
- 没有在本地覆盖文件里看到：
  - `cos_object_prefix`
  - `external_delivery_threshold_mb`
  - `cos_presign_expire_seconds`
- 这三个应继续沿用 `config.example.yaml` 默认值

## 7. 本包包含内容

### `repo/`

- `AGENTS.md`
- `README.md`
- `requirements.txt`
- `config.example.yaml`
- `mail_config.local.yaml`
- `mail_config.bot.local.yaml`
- `mail_config.cos.local.yaml`
- `docs/current/README.md`
- `docs/current/mail_protocol.md`
- `docs/current/android_runner_communication_contract.md`
- `docs/plans/vps_relay_deploy_runbook.md`
- `scripts/deploy_relay_server.py`
- `scripts/sync_relay_task_root.py`

### `live/`

- `mail_config.loop_30s.yaml`
- `relay_artifacts/relay_client_config.yaml`
- `relay_artifacts/relay-ca.crt`
- `relay_artifacts/relay_live_deploy.md`

### `external/`

- `work_bot.pem`
- `vps.txt`
- `codex_config.toml`

## 8. 迁移建议顺序

1. 在新机器安装与本机兼容的 Python 3.11.x，并重建 `.venv`
2. 先把 `repo/mail_config.bot.local.yaml` 和 `repo/mail_config.local.yaml` 放到仓库根目录
3. 如需 COS，再补 `repo/mail_config.cos.local.yaml`
4. 确认 `codex` / `opencode` 命令可自动发现；Codex 必要时重新登录
5. 如果要跑真实 relay：
   - 先用当前公网 `http://124.223.41.153:8787/healthz` 复核 live 状态
   - 再决定沿用历史 `wss + relay-ca.crt` 还是切回 `ws/http`
6. 如果要重新部署 VPS，再使用：
   - `external/work_bot.pem`
   - `repo/scripts/deploy_relay_server.py`
   - `repo/docs/plans/vps_relay_deploy_runbook.md`
