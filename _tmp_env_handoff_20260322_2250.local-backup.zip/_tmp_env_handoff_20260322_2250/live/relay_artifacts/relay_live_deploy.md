Relay live deployment summary

Deployed at: 2026-03-20 17:44 CST
VPS: 124.223.41.153
Service: mail-runner-relay
Public health: https://124.223.41.153:8787/healthz
Relay endpoint: wss://124.223.41.153:8787/relay
State dir: /opt/mail_runner_relay/shared/state
TLS mode: self-signed certificate with IP SAN for 124.223.41.153
Transport token: n_Wzz--Q_j4e_sI7uZHxGlttRLZHNns1z4y3MWVHVTU

Verification completed

- HTTPS health check succeeded with the downloaded CA file.
- WebSocket relay smoke succeeded.
- Relay delivered one smoke mail to sgjcc@qq.com.
- IMAP verification confirmed the smoke mail reached INBOX.
- systemd restart preserved packet/session history.

Smoke packet

- packet_id: live-smoke-5aec6acacac3
- subject: [mail-runner relay smoke] 2026-03-20T17:43:32
- relay ack message id: <177399981161.82227.12109814466843577405@mail-runner.local>
- IMAP inbox message id: <tencent_2F37E565055526B6F0A0E962CBFC3124E905@qq.com>

Local CA file

- E:/projects/mail_based_task_manager/_tmp_live_mail_runner/tasks/thread_076/runs/20260320_173414_b4c7/artifacts/relay-ca.crt
